﻿namespace MyVaccine.WebApi.Literals;

public static class MyVaccineLiterals
{
    public const string CONNECTION_STRING = "MY_VACCINE_CONNECTION_STRING";
    public const string JWT_KEY = "JWT_KEY";
}
