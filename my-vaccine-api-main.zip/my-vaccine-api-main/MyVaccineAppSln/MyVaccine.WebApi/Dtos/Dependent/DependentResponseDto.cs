﻿namespace MyVaccine.WebApi.Dtos.Dependent;

public class DependentResponseDto :DependentRequestDto
{
    public string Id { get; set; }
}
