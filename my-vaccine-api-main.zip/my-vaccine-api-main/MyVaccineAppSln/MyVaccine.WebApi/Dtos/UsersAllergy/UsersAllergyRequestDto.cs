﻿namespace MyVaccine.WebApi.Dtos.UsersAllergy
{
    public class UsersAllergyRequestDto
    {
        public string UserId { get; set; }

        public string AllergyId { get; set; }
    }
}
